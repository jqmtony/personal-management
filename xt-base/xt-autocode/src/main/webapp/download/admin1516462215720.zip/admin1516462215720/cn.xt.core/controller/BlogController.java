package cn.xt.core.controller;

import com.centnet.base.pagination.Pager;
import com.centnet.base.web.libs.controller.BaseController;
import org.springframework.stereotype.Controller;
import cn.xt.core.model.Blog;
import cn.xt.core.service.BlogService;
import javax.annotation.Resource;
import javax.validation.Valid;
import org.springframework.ui.Model;

/**
* blog的Controller
* Created by xtao on 2018-1-20.
*/
@Controller
@RequestMapping("blog")
public class BlogController extends BaseController{

    @Resource
    private BlogService blogService;

    /**
    * 跳转分页页面
    *
    * @return
    */
    @RequestMapping(value = "paging", method = RequestMethod.GET)
    public String toPaginationPage() {
        return "blog/blog-pagination";
    }

    /**
    * 分页查询
    *
    * @return
    */
    @ResponseBody
    @RequestMapping(value = "paging", method = RequestMethod.POST)
    public AjaxResult paging(BlogVo blogVo) {
        Pager<Blog> page = blogService.findPage(blogVo);
        return new AjaxResult(true, page);
    }

    /**
    * 创建Blog
    *
    * @param blog
    * @return
    */
    @ResponseBody
    @RequestMapping(value = "create", method = RequestMethod.POST)
    public AjaxResult create(@Valid Blog blog) {
        blog.setCreateBy(getPrincipalId());
        blogService.insert(blog);
        return new AjaxResult(true);
    }

    /**
    * 根据id获取Blog
    *
    * @param id id
    * @return
    */
    @ResponseBody
    @RequestMapping(value = "get", method = RequestMethod.GET)
    public AjaxResult get(long id) {
        Blog bean = blogService.get(id);
        return new AjaxResult(true, bean);
    }

    /**
    * 编辑Blog
    *
    * @param blog
    * @return
    */
    @ResponseBody
    @RequestMapping(value = "goEdit", method = RequestMethod.POST)
        public AjaxResult edit(@Valid Blog blog) {
        blog.setUpdateBy(getPrincipalId());
        blogService.update(blog);
        return new AjaxResult(true);
    }

    /**
    * 删除Blog
    *
    * @param id
    * @return
    */
    @ResponseBody
    @RequestMapping(value = "delete", method = RequestMethod.POST)
    public AjaxResult delete(Long id) {
        int deleted = blogService.delete(id);
        if( deleted > 0 ){
        	return new AjaxResult(true);
        }
        return new AjaxResult(false,"删除失败，请重试！");
    }
    
    /**
    * 批量删除Blog
    *
    * @param ids
    * @return
    */
    @ResponseBody
    @RequestMapping(value = "batchDelete", method = RequestMethod.POST)
    public AjaxResult delete(@RequestParam(name = "ids[]", required = false, defaultValue = "") Long[] ids) {
        int deleted blogService.batchDelete(ids);
        if( deleted > 0 && ids.length == deleted ){
        	return new AjaxResult(true);
        }
        return new AjaxResult(false,"有"+(ids.length - deleted)+"个资源删除失败，请重试！");
    }


}