package cn.xt.core.blog.dao;

import com.centnet.base.dao.BaseDao;
import cn.xt.core.model.Blog;
import org.apache.ibatis.annotations.Param;

/**
* dao
* Created by xtao on 2018-1-20.
*/
public interface BlogDao extends BaseDao<Blog> {
	
    /**
    * 批量删除
    * 
    * @param ids id数组
    */
	int batchDelete(@Param("ids") Long[] ids);
}