package cn.xt.core.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.util.Date;

/**
 * 
 *
 * Created by xtao on 2018-1-20.
 */
public class Blog implements Serializable{
	/**
     * 
     */
	private Long id;
	/**
     * 
     */
	private String title;
	/**
     * 
     */
	private byte contentType;
	/**
     * 
     */
	private String original;
	/**
     * 
     */
	private String html;
	/**
     * 
     */
	private String text;
	/**
     * 
     */
	private Date createTime;
	/**
     * 
     */
	private Long createBy;
	/**
     * 
     */
	private Date updateTime;
	/**
     * 
     */
	private Long updateBy;
	/**
     * 
     */
	private byte state;

	public void setId(Long id){
		this.id = id;
	}

	public Long getId(){
		return this.id;
	}
	public void setTitle(String title){
		this.title = title;
	}

	public String getTitle(){
		return this.title;
	}
	public void setContentType(byte contentType){
		this.contentType = contentType;
	}

	public byte getContentType(){
		return this.contentType;
	}
	public void setOriginal(String original){
		this.original = original;
	}

	public String getOriginal(){
		return this.original;
	}
	public void setHtml(String html){
		this.html = html;
	}

	public String getHtml(){
		return this.html;
	}
	public void setText(String text){
		this.text = text;
	}

	public String getText(){
		return this.text;
	}
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}

	public Date getCreateTime(){
		return this.createTime;
	}
	public void setCreateBy(Long createBy){
		this.createBy = createBy;
	}

	public Long getCreateBy(){
		return this.createBy;
	}
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}

	public Date getUpdateTime(){
		return this.updateTime;
	}
	public void setUpdateBy(Long updateBy){
		this.updateBy = updateBy;
	}

	public Long getUpdateBy(){
		return this.updateBy;
	}
	public void setState(byte state){
		this.state = state;
	}

	public byte getState(){
		return this.state;
	}
}