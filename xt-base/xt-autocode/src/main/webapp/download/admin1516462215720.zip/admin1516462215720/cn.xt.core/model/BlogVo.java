package cn.xt.core.model;

import cn.xt.core.model.Blog;
import com.centnet.base.pagination.PageQueryVo;

/**
* 的数据传输对象
* Created by xtao on 2018-1-20.
*/
public class BlogVo extends PageQueryVo{

}
