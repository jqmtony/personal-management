package cn.xt.core.service;

import com.centnet.base.service.BaseService;
import cn.xt.core.model.Blog;
/**
* 的服务层接口
* Created by xtao on 2018-1-20.
*/
public interface BlogService extends BaseService<Blog> {

	/**
    * 批量删除
    * 
    * @param ids id数组
    */
	int batchDelete(Long[] ids);
}