package cn.xt.core.service;

import com.centnet.base.service.BaseService;
import org.springframework.stereotype.Service;
import com.centnet.base.dao.BaseDao;
import com.centnet.base.service.BaseServiceImpl;
import javax.annotation.Resource;
import cn.xt.core.model.Blog;

/**
* 的服务层实现类
* Created by xtao on 2018-1-20.
*/
@Service
public class BlogServiceImpl extends BaseServiceImpl<Blog> implements BlogService {
    @Resource
    private BlogDao blogDao;

    @Override
    protected BaseDao<Blog> getDao() {
        return blogDao;
    }
    
    @Transactional
    @Override
    public int batchDelete(Long[] ids){
    	return blogDao.batchDelete(ids);
    }
    
}
