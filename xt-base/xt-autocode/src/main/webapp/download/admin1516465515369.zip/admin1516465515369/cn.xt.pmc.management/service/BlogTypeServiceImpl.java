package cn.xt.pmc.management.service;

import com.centnet.base.service.BaseService;
import org.springframework.stereotype.Service;
import com.centnet.base.dao.BaseDao;
import com.centnet.base.service.BaseServiceImpl;
import javax.annotation.Resource;
import cn.xt.pmc.management.model.BlogType;

/**
* 的服务层实现类
* Created by xtao on 2018-1-21.
*/
@Service
public class BlogTypeServiceImpl extends BaseServiceImpl<BlogType> implements BlogTypeService {
    @Resource
    private BlogTypeDao blogTypeDao;

    @Override
    protected BaseDao<BlogType> getDao() {
        return blogTypeDao;
    }
    
    @Transactional
    @Override
    public int batchDelete(Long[] ids){
    	return blogTypeDao.batchDelete(ids);
    }
    
}
