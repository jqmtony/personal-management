package cn.xt.pmc.management.controller;

import com.centnet.base.pagination.Pager;
import com.centnet.base.web.libs.controller.BaseController;
import org.springframework.stereotype.Controller;
import cn.xt.pmc.management.model.BlogType;
import cn.xt.pmc.management.service.BlogTypeService;
import javax.annotation.Resource;
import javax.validation.Valid;
import org.springframework.ui.Model;

/**
* blog_type的Controller
* Created by xtao on 2018-1-21.
*/
@Controller
@RequestMapping("blogType")
public class BlogTypeController extends BaseController{

    @Resource
    private BlogTypeService blogTypeService;

    /**
    * 跳转分页页面
    *
    * @return
    */
    @RequestMapping(value = "paging", method = RequestMethod.GET)
    public String toPaginationPage() {
        return "blogType/blogType-pagination";
    }

    /**
    * 分页查询
    *
    * @return
    */
    @ResponseBody
    @RequestMapping(value = "paging", method = RequestMethod.POST)
    public AjaxResult paging(BlogTypeVo blogTypeVo) {
        Pager<BlogType> page = blogTypeService.findPage(blogTypeVo);
        return new AjaxResult(true, page);
    }

    /**
    * 创建BlogType
    *
    * @param blogType
    * @return
    */
    @ResponseBody
    @RequestMapping(value = "create", method = RequestMethod.POST)
    public AjaxResult create(@Valid BlogType blogType) {
        blogType.setCreateBy(getPrincipalId());
        blogTypeService.insert(blogType);
        return new AjaxResult(true);
    }

    /**
    * 根据id获取BlogType
    *
    * @param id id
    * @return
    */
    @ResponseBody
    @RequestMapping(value = "get", method = RequestMethod.GET)
    public AjaxResult get(long id) {
        BlogType bean = blogTypeService.get(id);
        return new AjaxResult(true, bean);
    }

    /**
    * 编辑BlogType
    *
    * @param blogType
    * @return
    */
    @ResponseBody
    @RequestMapping(value = "goEdit", method = RequestMethod.POST)
        public AjaxResult edit(@Valid BlogType blogType) {
        blogType.setUpdateBy(getPrincipalId());
        blogTypeService.update(blogType);
        return new AjaxResult(true);
    }

    /**
    * 删除BlogType
    *
    * @param id
    * @return
    */
    @ResponseBody
    @RequestMapping(value = "delete", method = RequestMethod.POST)
    public AjaxResult delete(Long id) {
        int deleted = blogTypeService.delete(id);
        if( deleted > 0 ){
        	return new AjaxResult(true);
        }
        return new AjaxResult(false,"删除失败，请重试！");
    }
    
    /**
    * 批量删除BlogType
    *
    * @param ids
    * @return
    */
    @ResponseBody
    @RequestMapping(value = "batchDelete", method = RequestMethod.POST)
    public AjaxResult delete(@RequestParam(name = "ids[]", required = false, defaultValue = "") Long[] ids) {
        int deleted blogTypeService.batchDelete(ids);
        if( deleted > 0 && ids.length == deleted ){
        	return new AjaxResult(true);
        }
        return new AjaxResult(false,"有"+(ids.length - deleted)+"个资源删除失败，请重试！");
    }


}