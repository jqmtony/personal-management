package cn.xt.pmc.management.blogType.dao;

import com.centnet.base.dao.BaseDao;
import cn.xt.pmc.management.model.BlogType;
import org.apache.ibatis.annotations.Param;

/**
* dao
* Created by xtao on 2018-1-21.
*/
public interface BlogTypeDao extends BaseDao<BlogType> {
	
    /**
    * 批量删除
    * 
    * @param ids id数组
    */
	int batchDelete(@Param("ids") Long[] ids);
}