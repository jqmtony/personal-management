package cn.xt.pmc.management.model;

import cn.xt.pmc.management.model.BlogType;
import com.centnet.base.pagination.PageQueryVo;

/**
* 的数据传输对象
* Created by xtao on 2018-1-21.
*/
public class BlogTypeVo extends PageQueryVo{

}
